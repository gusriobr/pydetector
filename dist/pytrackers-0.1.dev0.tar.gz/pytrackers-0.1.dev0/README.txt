# pydetector
pet project used as prove concept to implement a mobile object tracker app based in different computer vision techniques.
